"""
Minimal Asterisk Manager Interface (AMI) client.

Yeastar's S-Series (S100 included) is Asterisk-based and exposes the same
AMI protocol used by any Asterisk box: a plain-text, line-based protocol
over a raw TCP socket. No third-party library is required - this is a
self-contained client using only Python's standard library.
"""

import socket
import logging

log = logging.getLogger("ami_client")


class AMIError(Exception):
    pass


class AMIClient:
    def __init__(self, host, port, username, secret, on_event, timeout=15):
        self.host = host
        self.port = port
        self.username = username
        self.secret = secret
        self.on_event = on_event
        self.timeout = timeout
        self.sock = None
        self._buffer = ""

    def connect(self):
        log.info("Connecting to AMI at %s:%s", self.host, self.port)
        self.sock = socket.create_connection((self.host, self.port), timeout=self.timeout)
        self.sock.settimeout(self.timeout)
        greeting = self._read_line()
        log.info("AMI greeting: %s", greeting)

        self._send_action({
            "Action": "Login",
            "Username": self.username,
            "Secret": self.secret,
            "Events": "on",
        })
        response = self._read_block()
        if response.get("Response") != "Success":
            raise AMIError(f"AMI login failed: {response}")
        log.info("AMI login successful")
        # No read timeout once logged in - this is a long-lived event stream.
        self.sock.settimeout(None)
        return greeting

    def _send_action(self, fields):
        msg = "".join(f"{k}: {v}\r\n" for k, v in fields.items()) + "\r\n"
        self.sock.sendall(msg.encode("utf-8", errors="ignore"))

    def _read_line(self):
        while "\n" not in self._buffer:
            chunk = self.sock.recv(4096)
            if not chunk:
                raise AMIError("AMI connection closed by remote host")
            self._buffer += chunk.decode("utf-8", errors="ignore")
        line, self._buffer = self._buffer.split("\n", 1)
        return line.rstrip("\r")

    def _read_block(self):
        """Read key: value lines until a blank line terminates the block."""
        block = {}
        while True:
            line = self._read_line()
            if line == "":
                break
            if ": " in line:
                key, value = line.split(": ", 1)
                block[key] = value
        return block

    def run_forever(self):
        """Blocks, dispatching every event/response block to on_event."""
        while True:
            block = self._read_block()
            if block:
                self.on_event(block)

    def close(self):
        if self.sock:
            try:
                self.sock.close()
            except OSError:
                pass
