"""SQLite storage layer. Uses only Python's built-in sqlite3 module."""

import sqlite3
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS calls (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    uniqueid TEXT UNIQUE,
    direction TEXT,          -- inbound / outbound / internal / unknown
    caller TEXT,
    destination TEXT,
    extension TEXT,          -- the local extension involved in the call
    start_time TEXT,
    answer_time TEXT,
    end_time TEXT,
    duration INTEGER,
    billsec INTEGER,
    disposition TEXT,        -- ANSWERED / NO ANSWER / BUSY / FAILED
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS followups (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    call_id INTEGER,
    caller TEXT,
    extension TEXT,
    missed_at TEXT,
    status TEXT DEFAULT 'open',   -- open / resolved
    resolved_at TEXT,
    FOREIGN KEY(call_id) REFERENCES calls(id)
);

CREATE INDEX IF NOT EXISTS idx_calls_start_time ON calls(start_time);
CREATE INDEX IF NOT EXISTS idx_followups_status ON followups(status);
"""


def get_connection(db_path):
    Path(db_path).parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    conn.executescript(SCHEMA)
    return conn
