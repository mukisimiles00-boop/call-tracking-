"""
Masca Call Command Center - a fun, live dashboard for whoever is
monitoring calls day to day.

Reads straight from the same calls.db the listener (main.py) writes to.
No external dependencies - built-in http.server only. Auto-refreshes in
the browser every few seconds, no page reload needed.

Access control:
- The whole dashboard sits behind a single admin login (HTTP Basic Auth),
  configured via admin_username / admin_password in config.json.
- Once logged in, the admin can switch the view between "All Staff"
  (everyone with a phone) and any one named person, via a dropdown at
  the top of the page. Switching the view filters every panel on the
  page to that person's extension only.

Run:
    python3 dashboard_server.py
Then open http://localhost:8088 in a browser (on the same server, or
from another machine on the network using that server's IP instead of
localhost).
"""

import base64
import json
import sqlite3
import sys
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs

sys.path.insert(0, str(Path(__file__).parent))
from report import caller_report_data, render_caller_html, weekly_report_html

PROJECT_ROOT = Path(__file__).parent.parent
CONFIG_PATH = PROJECT_ROOT / "config.json"
LOGO_PATH = Path(__file__).parent / "assets" / "masca_logo_b64.txt"
PORT = 8088


def load_config():
    with open(CONFIG_PATH) as f:
        return json.load(f)


def resolve_db_path(config):
    db_path = Path(config["db_path"])
    if not db_path.is_absolute():
        db_path = (PROJECT_ROOT / db_path).resolve()
    return db_path


def load_logo_b64():
    try:
        return LOGO_PATH.read_text().strip()
    except FileNotFoundError:
        return ""


def get_directory(db_path, config):
    """
    Combines the named staff directory from config.json with any
    extensions seen in the call log that aren't in it yet, so a new
    phone shows up (as "Extension 1005") even before someone names it
    in config.json.
    """
    staff_directory = config.get("staff_directory", {})
    conn = sqlite3.connect(db_path)
    seen = conn.execute(
        "SELECT DISTINCT extension FROM calls WHERE extension IS NOT NULL AND extension != ''"
    ).fetchall()
    conn.close()

    entries = dict(staff_directory)
    for (ext,) in seen:
        entries.setdefault(ext, f"Extension {ext}")

    return [
        {"extension": ext, "name": name}
        for ext, name in sorted(entries.items(), key=lambda kv: kv[1].lower())
    ]


def get_stats(db_path, extension=None):
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row

    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    ext_filter = " AND extension = ?" if extension else ""
    ext_params = (extension,) if extension else ()

    totals_today = conn.execute(
        f"SELECT direction, COUNT(*) c FROM calls WHERE start_time LIKE ?{ext_filter} GROUP BY direction",
        (f"{today}%", *ext_params),
    ).fetchall()
    totals_map = {r["direction"]: r["c"] for r in totals_today}

    missed_today = conn.execute(
        f"""SELECT COUNT(*) c FROM calls
            WHERE direction='inbound' AND disposition!='ANSWERED' AND start_time LIKE ?{ext_filter}""",
        (f"{today}%", *ext_params),
    ).fetchone()["c"]

    resolved_today = conn.execute(
        f"SELECT COUNT(*) c FROM followups WHERE status='resolved' AND resolved_at LIKE ?{ext_filter}",
        (f"{today}%", *ext_params),
    ).fetchone()["c"]

    open_followups = conn.execute(
        f"SELECT caller, extension, missed_at FROM followups WHERE status='open'{ext_filter} ORDER BY missed_at ASC",
        ext_params,
    ).fetchall()

    # The "Follow-Up Heroes" leaderboard always shows the whole company,
    # regardless of which person is currently selected - it's a
    # team view, not a per-person one.
    leaderboard = conn.execute(
        """SELECT extension, COUNT(*) resolved_count
           FROM followups WHERE status='resolved' AND extension IS NOT NULL
           GROUP BY extension ORDER BY resolved_count DESC LIMIT 5"""
    ).fetchall()

    recent_calls = conn.execute(
        f"""SELECT direction, caller, destination, extension, disposition, start_time
            FROM calls WHERE 1=1{ext_filter} ORDER BY id DESC LIMIT 12""",
        ext_params,
    ).fetchall()

    conn.close()
    now = datetime.now(timezone.utc)

    def minutes_open(missed_at):
        try:
            t = datetime.fromisoformat(missed_at)
            if t.tzinfo is None:
                t = t.replace(tzinfo=timezone.utc)
            return max(0, round((now - t).total_seconds() / 60))
        except Exception:
            return None

    return {
        "generated_at": now.isoformat(),
        "viewing_extension": extension,
        "today": {
            "inbound": totals_map.get("inbound", 0),
            "outbound": totals_map.get("outbound", 0),
            "internal": totals_map.get("internal", 0),
            "missed": missed_today,
            "resolved": resolved_today,
        },
        "open_followups": [
            {"caller": r["caller"], "extension": r["extension"],
             "missed_at": r["missed_at"], "minutes_open": minutes_open(r["missed_at"])}
            for r in open_followups
        ],
        "leaderboard": [
            {"extension": r["extension"], "resolved_count": r["resolved_count"]}
            for r in leaderboard
        ],
        "recent_calls": [
            {"direction": r["direction"], "caller": r["caller"], "destination": r["destination"],
             "extension": r["extension"], "disposition": r["disposition"], "start_time": r["start_time"]}
            for r in recent_calls
        ],
    }


def render_page(logo_b64):
    logo_tag = (
        f'<img src="data:image/png;base64,{logo_b64}" alt="Masca" class="logo">'
        if logo_b64 else '<div class="logo-fallback">masca</div>'
    )
    return f"""<!doctype html>
<html><head><meta charset="utf-8">
<title>Masca Call Command Center</title>
<style>
  :root {{
    --red: #C8102E; --dark: #231F20; --grey: #6b6b6b; --bg: #f4f2f0;
    --green: #1e9e5a; --amber: #d98c00;
  }}
  * {{ box-sizing: border-box; }}
  body {{
    margin: 0; font-family: -apple-system, Segoe UI, Arial, sans-serif;
    background: var(--bg); color: var(--dark);
  }}
  header {{
    display: flex; align-items: center; justify-content: space-between;
    background: white; padding: 14px 28px; border-bottom: 4px solid var(--red);
    box-shadow: 0 2px 6px rgba(0,0,0,0.06); flex-wrap: wrap; gap: 12px;
  }}
  .brand {{ display: flex; align-items: center; gap: 14px; }}
  .logo {{ height: 42px; }}
  .logo-fallback {{ font-weight: 900; color: var(--red); font-size: 24px; }}
  header h1 {{ font-size: 19px; margin: 0; color: var(--dark); }}
  header .subtitle {{ font-size: 12.5px; color: var(--grey); }}
  .header-controls {{ display: flex; align-items: center; gap: 10px; }}
  #view-select {{
    border: 2px solid #ddd; border-radius: 20px; padding: 7px 14px;
    font-weight: 700; font-size: 13px; color: var(--dark); background: white;
    cursor: pointer;
  }}
  #sound-toggle {{
    border: 2px solid var(--red); background: white; color: var(--red);
    border-radius: 20px; padding: 8px 16px; font-weight: 700; cursor: pointer;
    font-size: 13px; transition: all .15s;
  }}
  #sound-toggle.on {{ background: var(--red); color: white; }}
  .report-btn {{
    border: 2px solid var(--red); background: var(--red); color: white;
    border-radius: 20px; padding: 8px 16px; font-weight: 700; cursor: pointer;
    font-size: 13px; text-decoration: none; display: inline-block;
  }}
  .report-btn.outline {{ background: white; color: var(--red); }}
  main {{ max-width: 1180px; margin: 0 auto; padding: 22px 20px 60px; }}
  .viewing-banner {{
    background: #fff4f0; border: 1px solid #f3cfc0; color: var(--dark);
    border-radius: 10px; padding: 9px 16px; font-size: 13.5px; margin-bottom: 18px;
    display: none;
  }}
  .viewing-banner.show {{ display: block; }}
  .viewing-banner strong {{ color: var(--red); }}

  .stat-grid {{
    display: grid; grid-template-columns: repeat(5, 1fr); gap: 14px; margin-bottom: 24px;
  }}
  @media (max-width: 900px) {{ .stat-grid {{ grid-template-columns: repeat(2, 1fr); }} }}
  .stat-card {{
    background: white; border-radius: 14px; padding: 16px 14px; text-align: center;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06); position: relative; overflow: hidden;
  }}
  .stat-card .num {{ font-size: 34px; font-weight: 800; line-height: 1; }}
  .stat-card .label {{ font-size: 12.5px; color: var(--grey); margin-top: 6px; font-weight: 600; }}
  .stat-card.missed .num {{ color: var(--red); }}
  .stat-card.resolved .num {{ color: var(--green); }}

  .panels {{ display: grid; grid-template-columns: 1.3fr 1fr; gap: 18px; }}
  @media (max-width: 900px) {{ .panels {{ grid-template-columns: 1fr; }} }}
  .panel {{
    background: white; border-radius: 14px; padding: 18px 20px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06); margin-bottom: 18px;
  }}
  .panel h2 {{ font-size: 15px; margin: 0 0 12px; color: var(--dark); }}
  .panel h2 .emoji {{ margin-right: 6px; }}

  .call-row {{
    display: flex; align-items: center; gap: 10px; padding: 8px 0;
    border-bottom: 1px solid #eee; font-size: 13.5px;
  }}
  .call-row:last-child {{ border-bottom: none; }}
  .call-icon {{ font-size: 17px; width: 22px; text-align: center; }}
  .call-meta {{ flex: 1; }}
  .call-tag {{
    font-size: 11px; font-weight: 700; padding: 2px 8px; border-radius: 10px;
    background: #eee; color: var(--grey);
  }}
  .call-tag.missed {{ background: #fde3e7; color: var(--red); }}
  .call-tag.answered {{ background: #e3f6ec; color: var(--green); }}

  .followup-row {{
    display: flex; align-items: center; justify-content: space-between;
    padding: 10px 0; border-bottom: 1px solid #eee; font-size: 13.5px;
  }}
  .followup-row:last-child {{ border-bottom: none; }}
  .chip {{ font-size: 11.5px; font-weight: 800; padding: 3px 10px; border-radius: 12px; color: white; }}
  .chip.ok {{ background: var(--green); }}
  .chip.warn {{ background: var(--amber); }}
  .chip.urgent {{ background: var(--red); }}

  .empty {{ color: var(--grey); font-size: 13.5px; padding: 10px 0; }}

  .leaderboard-row {{ display: flex; align-items: center; gap: 10px; padding: 8px 0; font-size: 14px; }}
  .medal {{ font-size: 18px; width: 26px; text-align: center; }}
  .bar-track {{ flex: 1; background: #eee; border-radius: 6px; height: 10px; overflow: hidden; }}
  .bar-fill {{ background: var(--red); height: 100%; border-radius: 6px; }}

  #toast-container {{
    position: fixed; top: 18px; right: 18px; z-index: 999;
    display: flex; flex-direction: column; gap: 10px; align-items: flex-end;
  }}
  .toast {{
    background: var(--dark); color: white; padding: 12px 18px; border-radius: 10px;
    font-size: 13.5px; box-shadow: 0 4px 14px rgba(0,0,0,0.25);
    animation: slidein .25s ease-out;
  }}
  @keyframes slidein {{ from {{ transform: translateX(30px); opacity: 0; }} to {{ transform: translateX(0); opacity: 1; }} }}

  footer {{ text-align: center; color: var(--grey); font-size: 12px; padding: 14px; }}
</style>
</head>
<body>
  <header>
    <div class="brand">
      {logo_tag}
      <div>
        <h1>Call Command Center</h1>
        <div class="subtitle">Live view of everything happening on the phones right now</div>
      </div>
    </div>
    <div class="header-controls">
      <select id="view-select" onchange="onViewChange()">
        <option value="">All Staff (everyone with a phone)</option>
      </select>
      <a class="report-btn" id="caller-report-link" href="/report/callers" target="_blank">\U0001F5A8\uFE0F Caller Report</a>
      <a class="report-btn outline" href="/report/weekly" target="_blank">\U0001F5A8\uFE0F Weekly Report</a>
      <button id="sound-toggle" onclick="toggleSound()">\U0001F515 Sound off</button>
    </div>
  </header>

  <main>
    <div class="viewing-banner" id="viewing-banner"></div>
    <div class="stat-grid" id="stat-grid"></div>
    <div class="panels">
      <div>
        <div class="panel">
          <h2><span class="emoji">\U0001F6A8</span>Follow-Ups Needing Action</h2>
          <div id="followups"></div>
        </div>
        <div class="panel">
          <h2><span class="emoji">\U0001F4DE</span>Live Call Feed</h2>
          <div id="feed"></div>
        </div>
      </div>
      <div>
        <div class="panel">
          <h2><span class="emoji">\U0001F3C6</span>Today's Follow-Up Heroes</h2>
          <div id="leaderboard"></div>
        </div>
      </div>
    </div>
  </main>

  <footer>Masca Call Command Center &middot; auto-refreshes every 5 seconds</footer>
  <div id="toast-container"></div>

<script>
let soundOn = false;
let prevMissed = null;
let prevResolved = null;
let staffNames = {{}};   // extension -> name, filled in from /api/directory

function toggleSound() {{
  soundOn = !soundOn;
  const btn = document.getElementById('sound-toggle');
  btn.textContent = soundOn ? '\\uD83D\\uDD0A Sound on' : '\\uD83D\\uDD15 Sound off';
  btn.classList.toggle('on', soundOn);
  if (soundOn) beep(440, 0.08);
}}

function beep(freq, duration) {{
  try {{
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.frequency.value = freq;
    osc.connect(gain);
    gain.connect(ctx.destination);
    gain.gain.setValueAtTime(0.15, ctx.currentTime);
    osc.start();
    osc.stop(ctx.currentTime + duration);
  }} catch (e) {{}}
}}

function toast(text) {{
  const container = document.getElementById('toast-container');
  const el = document.createElement('div');
  el.className = 'toast';
  el.textContent = text;
  container.appendChild(el);
  setTimeout(() => el.remove(), 5000);
}}

function fmtIcon(direction, disposition) {{
  if (direction === 'inbound' && disposition !== 'ANSWERED') return '\\u274C';
  if (direction === 'inbound') return '\\uD83D\\uDCDE';
  if (direction === 'outbound') return '\\u260E\\uFE0F';
  return '\\uD83C\\uDFE0';
}}

function personLabel(extension) {{
  if (!extension) return '-';
  return staffNames[extension] || ('Ext ' + extension);
}}

function onViewChange() {{
  const sel = document.getElementById('view-select');
  const banner = document.getElementById('viewing-banner');
  const reportLink = document.getElementById('caller-report-link');
  if (sel.value) {{
    reportLink.href = '/report/callers?extension=' + encodeURIComponent(sel.value);
    banner.innerHTML = 'Viewing: <strong>' + personLabel(sel.value) + '</strong> only. ' +
      '<a href="#" onclick="document.getElementById(\\'view-select\\').value=\\'\\'; onViewChange(); return false;">Switch back to All Staff</a>';
    banner.classList.add('show');
  }} else {{
    reportLink.href = '/report/callers';
    banner.classList.remove('show');
  }}
  prevMissed = null;
  prevResolved = null;
  poll();
}}

async function loadDirectory() {{
  try {{
    const res = await fetch('/api/directory');
    const people = await res.json();
    const sel = document.getElementById('view-select');
    people.forEach(p => {{
      staffNames[p.extension] = p.name;
      const opt = document.createElement('option');
      opt.value = p.extension;
      opt.textContent = p.name + ' (ext ' + p.extension + ')';
      sel.appendChild(opt);
    }});
  }} catch (e) {{
    console.error('Failed to load staff directory', e);
  }}
}}

function renderStats(t) {{
  const cards = [
    {{ label: 'Inbound Today', value: t.inbound, cls: '' }},
    {{ label: 'Outbound Today', value: t.outbound, cls: '' }},
    {{ label: 'Internal Today', value: t.internal, cls: '' }},
    {{ label: 'Missed Today', value: t.missed, cls: 'missed' }},
    {{ label: 'Resolved Today', value: t.resolved, cls: 'resolved' }},
  ];
  document.getElementById('stat-grid').innerHTML = cards.map(c =>
    `<div class="stat-card ${{c.cls}}"><div class="num">${{c.value}}</div><div class="label">${{c.label}}</div></div>`
  ).join('');
}}

function renderFollowups(list) {{
  const el = document.getElementById('followups');
  if (!list.length) {{
    el.innerHTML = '<div class="empty">\\uD83C\\uDF89 No missed calls waiting on a callback right now. Nicely done.</div>';
    return;
  }}
  el.innerHTML = list.map(f => {{
    let chipClass = 'ok', chipText = f.minutes_open + ' min';
    if (f.minutes_open >= 30) {{ chipClass = 'urgent'; chipText = f.minutes_open + ' min - URGENT'; }}
    else if (f.minutes_open >= 10) {{ chipClass = 'warn'; chipText = f.minutes_open + ' min'; }}
    return `<div class="followup-row">
      <span>\\uD83D\\uDCDE ${{f.caller}} &rarr; ${{personLabel(f.extension)}}</span>
      <span class="chip ${{chipClass}}">${{chipText}}</span>
    </div>`;
  }}).join('');
}}

function renderFeed(calls) {{
  const el = document.getElementById('feed');
  if (!calls.length) {{
    el.innerHTML = '<div class="empty">No calls logged yet today.</div>';
    return;
  }}
  el.innerHTML = calls.map(c => {{
    const tagClass = c.disposition === 'ANSWERED' ? 'answered' : (c.direction === 'inbound' ? 'missed' : '');
    return `<div class="call-row">
      <span class="call-icon">${{fmtIcon(c.direction, c.disposition)}}</span>
      <span class="call-meta">${{c.caller}} &rarr; ${{c.destination}} <span style="color:#999;">(${{personLabel(c.extension)}})</span></span>
      <span class="call-tag ${{tagClass}}">${{c.disposition || c.direction}}</span>
    </div>`;
  }}).join('');
}}

function renderLeaderboard(list) {{
  const el = document.getElementById('leaderboard');
  if (!list.length) {{
    el.innerHTML = '<div class="empty">No resolved follow-ups yet - first one on the board wins \\uD83C\\uDFC5</div>';
    return;
  }}
  const medals = ['\\uD83E\\uDD47', '\\uD83E\\uDD48', '\\uD83E\\uDD49', '\\uD83C\\uDF96\\uFE0F', '\\uD83C\\uDF96\\uFE0F'];
  const max = Math.max(...list.map(l => l.resolved_count));
  el.innerHTML = list.map((l, i) => `
    <div class="leaderboard-row">
      <span class="medal">${{medals[i] || '\\u2B50'}}</span>
      <span style="width:140px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">${{personLabel(l.extension)}}</span>
      <div class="bar-track"><div class="bar-fill" style="width:${{(l.resolved_count / max * 100).toFixed(0)}}%"></div></div>
      <span style="width:26px; text-align:right; font-weight:700;">${{l.resolved_count}}</span>
    </div>`
  ).join('');
}}

async function poll() {{
  try {{
    const selected = document.getElementById('view-select').value;
    const url = selected ? ('/api/stats?extension=' + encodeURIComponent(selected)) : '/api/stats';
    const res = await fetch(url);
    const data = await res.json();
    renderStats(data.today);
    renderFollowups(data.open_followups);
    renderFeed(data.recent_calls);
    renderLeaderboard(data.leaderboard);

    if (prevMissed !== null && data.today.missed > prevMissed) {{
      toast('\\uD83D\\uDCDE Missed call just came in - go get it!');
      if (soundOn) beep(880, 0.15);
    }}
    if (prevResolved !== null && data.today.resolved > prevResolved) {{
      toast('\\u2705 Follow-up resolved - nice work!');
      if (soundOn) beep(660, 0.12);
    }}
    prevMissed = data.today.missed;
    prevResolved = data.today.resolved;
  }} catch (e) {{
    console.error('Failed to fetch stats', e);
  }}
}}

loadDirectory().then(poll);
setInterval(poll, 5000);
</script>
</body></html>"""


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass  # keep the console quiet

    def _authorized(self, config):
        admin_user = config.get("admin_username")
        admin_pass = config.get("admin_password")
        if not admin_user or not admin_pass:
            return True  # no credentials configured - auth disabled

        header = self.headers.get("Authorization", "")
        if not header.startswith("Basic "):
            return False
        try:
            decoded = base64.b64decode(header[6:]).decode("utf-8")
            user, _, pw = decoded.partition(":")
        except Exception:
            return False
        return user == admin_user and pw == admin_pass

    def _require_auth(self):
        body = b"Login required to view the Call Command Center."
        self.send_response(401)
        self.send_header("WWW-Authenticate", 'Basic realm="Masca Call Command Center"')
        self.send_header("Content-Type", "text/plain")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        config = load_config()
        if not self._authorized(config):
            self._require_auth()
            return

        parsed = urlparse(self.path)
        path = parsed.path
        if path == "/api/stats":
            self._serve_stats(config, parse_qs(parsed.query))
        elif path == "/api/directory":
            self._serve_directory(config)
        elif path == "/report/callers":
            self._serve_caller_report(config, parse_qs(parsed.query))
        elif path == "/report/weekly":
            self._serve_weekly_report(config)
        else:
            self._serve_page()

    def _serve_stats(self, config, query):
        try:
            extension = (query.get("extension") or [None])[0] or None
            stats = get_stats(resolve_db_path(config), extension=extension)
            body = json.dumps(stats).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Cache-Control", "no-store")
        except Exception as e:
            body = json.dumps({"error": str(e)}).encode()
            self.send_response(500)
            self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _serve_directory(self, config):
        try:
            directory = get_directory(resolve_db_path(config), config)
            body = json.dumps(directory).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
        except Exception as e:
            body = json.dumps({"error": str(e)}).encode()
            self.send_response(500)
            self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _serve_page(self):
        body = render_page(load_logo_b64()).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _report_conn(self, config):
        conn = sqlite3.connect(str(resolve_db_path(config)))
        conn.row_factory = sqlite3.Row
        return conn

    def _send_html(self, html):
        body = html.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _serve_caller_report(self, config, query):
        """Printable per-caller report: every caller's missed, answered and
        followed-back calls. Optional ?extension= and ?days= filters."""
        try:
            extension = (query.get("extension") or [None])[0] or None
            days = (query.get("days") or [None])[0]
            start = end = None
            if days:
                try:
                    end = datetime.now(timezone.utc)
                    from datetime import timedelta
                    start = end - timedelta(days=int(days))
                except ValueError:
                    start = end = None
            conn = self._report_conn(config)
            data = caller_report_data(conn, extension=extension, start=start, end=end)
            conn.close()
            html = render_caller_html(
                data, start=start, end=end, extension=extension,
                staff_directory=config.get("staff_directory", {}),
            )
            self._send_html(html)
        except Exception as e:
            self._send_html(f"<p>Could not build the caller report: {e}</p>")

    def _serve_weekly_report(self, config):
        """Printable weekly report page (last 7 days)."""
        try:
            conn = self._report_conn(config)
            html = weekly_report_html(conn)
            conn.close()
            self._send_html(html)
        except Exception as e:
            self._send_html(f"<p>Could not build the weekly report: {e}</p>")


def main():
    server = ThreadingHTTPServer(("0.0.0.0", PORT), Handler)
    print(f"Masca Call Command Center running - open http://localhost:{PORT} in a browser")
    server.serve_forever()


if __name__ == "__main__":
    main()
