"""Missed-call alerting. Ships with email (SMTP) support, disabled by default."""

import smtplib
import logging
from email.mime.text import MIMEText

log = logging.getLogger("notifier")


class Notifier:
    def __init__(self, config):
        self.config = config.get("email", {}) or {}

    def notify_missed_call(self, caller, extension):
        if not self.config.get("enabled"):
            log.info("[notify-disabled] missed call from %s on extension %s", caller, extension)
            return

        to_address = self.config.get("extension_map", {}).get(extension) or self.config.get("default_to")
        if not to_address:
            log.warning("No notification recipient configured for extension %s", extension)
            return

        msg = MIMEText(
            f"Missed call from {caller} on extension {extension}.\n\n"
            f"Please follow up with this caller as soon as possible."
        )
        msg["Subject"] = f"Missed call - extension {extension}"
        msg["From"] = self.config["from_address"]
        msg["To"] = to_address

        try:
            with smtplib.SMTP(self.config["smtp_host"], self.config.get("smtp_port", 587)) as server:
                if self.config.get("use_tls", True):
                    server.starttls()
                if self.config.get("smtp_user"):
                    server.login(self.config["smtp_user"], self.config["smtp_password"])
                server.sendmail(self.config["from_address"], [to_address], msg.as_string())
            log.info("Missed-call alert emailed to %s", to_address)
        except Exception:
            log.exception("Failed to send missed-call email alert")
