"""
Generates, prints, and (optionally) emails the per-caller report - every
caller's missed, answered and followed-back calls. Can be run by hand or
by cron, the same way as run_weekly_report.py.

    python3 run_caller_report.py            # all-time, send to printer
    python3 run_caller_report.py --days 7   # just the last 7 days
    python3 run_caller_report.py --no-print # build the file only
"""

import json
import logging
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from db import get_connection
from report import generate_caller_report, print_report

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
log = logging.getLogger("caller_report")


def load_config():
    config_path = Path(__file__).parent.parent / "config.json"
    with open(config_path) as f:
        return json.load(f)


def main():
    args = sys.argv[1:]
    start = end = None
    if "--days" in args:
        try:
            days = int(args[args.index("--days") + 1])
            end = datetime.now(timezone.utc)
            start = end - timedelta(days=days)
        except (ValueError, IndexError):
            log.warning("--days needs a number, e.g. --days 7; ignoring it")

    config = load_config()
    conn = get_connection(config["db_path"])

    path = generate_caller_report(
        conn, config, config["report_output_dir"],
        start=start, end=end,
        staff_directory=config.get("staff_directory", {}),
    )
    log.info("Caller report generated: %s", path)

    if "--no-print" not in args and config.get("printer_name"):
        print_report(path, config["printer_name"])


if __name__ == "__main__":
    main()
