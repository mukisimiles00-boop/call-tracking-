"""
One-command LIVE DEMO of the whole Masca call tracking system.

    py demo.py

It starts, all in this one window:
  1. a fake Yeastar S100 that "receives" a new phone call every few seconds
  2. the real listener (the same code that will talk to your S100)
  3. the real Call Command Center dashboard, and opens it in your browser

Nothing here touches your real config.json or your real call database -
the demo uses its own throw-away database (data/demo_calls.db).

Dashboard login for the demo:  admin / demo
Press Ctrl+C in this window to stop everything.
"""

import logging
import random
import socket
import sys
import threading
import time
import webbrowser
from datetime import datetime, timezone
from http.server import ThreadingHTTPServer
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

import dashboard_server as ds
from ami_client import AMIClient, AMIError
from call_processor import process_cdr_event
from db import get_connection

PROJECT_ROOT = Path(__file__).parent.parent
DEMO_DB = PROJECT_ROOT / "data" / "demo_calls.db"
AMI_PORT = 15039
DASHBOARD_PORT = 8088

DEMO_CONFIG = {
    "ami_host": "127.0.0.1",
    "ami_port": AMI_PORT,
    "ami_username": "demo",
    "ami_secret": "demo",
    "db_path": str(DEMO_DB),
    "extension_pattern": r"^[1-9][0-9]{2,3}$",
    "admin_username": "admin",
    "admin_password": "demo",
    "staff_directory": {
        "1001": "Jane Moyo",
        "1002": "John Ncube",
        "1003": "Sipho Dube",
    },
}

EXTENSIONS = ["1001", "1002", "1003"]
CUSTOMERS = ["0771234567", "0779876543", "0771112222", "0775550000", "0778889999", "0712345678"]


def now_str():
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")


# ---------------------------------------------------------------- fake PBX
class FakePBX(threading.Thread):
    """Speaks just enough AMI to feed the listener a stream of phone calls."""

    def __init__(self):
        super().__init__(daemon=True)
        self.counter = 0
        self.missed_numbers = []  # customers we "missed" and may call back

    def make_event(self):
        self.counter += 1
        roll = random.random()
        ext = random.choice(EXTENSIONS)

        if roll < 0.45:        # answered inbound call
            src, dst, disp, dur = random.choice(CUSTOMERS), ext, "ANSWERED", random.randint(30, 300)
        elif roll < 0.70:      # missed inbound call
            src, dst, disp, dur = random.choice(CUSTOMERS), ext, "NO ANSWER", random.randint(8, 25)
            self.missed_numbers.append((src, ext))
        elif roll < 0.88 and self.missed_numbers:   # someone calls a missed customer back
            number, ext = self.missed_numbers.pop(0)
            src, dst, disp, dur = ext, number, "ANSWERED", random.randint(40, 200)
        elif roll < 0.95:      # normal outbound call
            src, dst, disp, dur = ext, random.choice(CUSTOMERS), "ANSWERED", random.randint(20, 240)
        else:                  # call between two colleagues
            other = random.choice([e for e in EXTENSIONS if e != ext])
            src, dst, disp, dur = ext, other, "ANSWERED", random.randint(15, 120)

        t = now_str()
        return {
            "Event": "Cdr", "Source": src, "Destination": dst,
            "Channel": f"SIP/demo-{self.counter:08d}",
            "StartTime": t, "AnswerTime": t if disp == "ANSWERED" else "", "EndTime": t,
            "Duration": str(dur), "BillableSeconds": str(dur if disp == "ANSWERED" else 0),
            "Disposition": disp, "UniqueID": f"demo-live-{int(time.time())}-{self.counter}",
        }

    def serve(self, conn):
        conn.sendall(b"Asterisk Call Manager/2.10.3\r\n")
        data = b""
        while b"\r\n\r\n" not in data:
            chunk = conn.recv(4096)
            if not chunk:
                return
            data += chunk
        conn.sendall(b"Response: Success\r\nMessage: Authentication accepted\r\n\r\n")
        time.sleep(1)
        first = True
        while True:
            ev = self.make_event()
            block = "".join(f"{k}: {v}\r\n" for k, v in ev.items()) + "\r\n"
            conn.sendall(block.encode())
            time.sleep(1.5 if first else random.uniform(4, 7))
            first = False

    def run(self):
        srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        srv.bind(("127.0.0.1", AMI_PORT))
        srv.listen(5)
        while True:
            conn, _ = srv.accept()
            try:
                self.serve(conn)
            except (ConnectionError, OSError):
                pass
            finally:
                conn.close()


# ---------------------------------------------------------------- listener
def run_listener():
    conn = get_connection(str(DEMO_DB))  # created inside this thread (sqlite rule)

    def handle(event):
        try:
            process_cdr_event(event, conn, DEMO_CONFIG, notifier=None)
        except Exception:
            logging.exception("Error processing event")

    while True:
        client = AMIClient("127.0.0.1", AMI_PORT, "demo", "demo", handle)
        try:
            client.connect()
            client.run_forever()
        except (AMIError, OSError):
            time.sleep(2)
        finally:
            client.close()


# ---------------------------------------------------------------- main
def main():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s  %(message)s", datefmt="%H:%M:%S")
    logging.getLogger("ami_client").setLevel(logging.WARNING)

    DEMO_DB.parent.mkdir(parents=True, exist_ok=True)
    if DEMO_DB.exists():
        DEMO_DB.unlink()  # start every demo from a clean slate

    ds.load_config = lambda: DEMO_CONFIG  # dashboard uses demo settings, not your real ones

    try:
        web = ThreadingHTTPServer(("127.0.0.1", DASHBOARD_PORT), ds.Handler)
    except OSError:
        print(f"\nPort {DASHBOARD_PORT} is already in use - close any other dashboard window and try again.")
        return
    threading.Thread(target=web.serve_forever, daemon=True).start()
    FakePBX().start()
    time.sleep(0.5)
    threading.Thread(target=run_listener, daemon=True).start()

    url = f"http://localhost:{DASHBOARD_PORT}"
    print("=" * 62)
    print("  MASCA CALL TRACKING - LIVE DEMO")
    print("=" * 62)
    print(f"  Dashboard : {url}")
    print("  Login     : admin  /  demo")
    print("  A fake phone call arrives every few seconds - watch the")
    print("  numbers change in your browser. Press Ctrl+C to stop.")
    print("=" * 62)
    try:
        webbrowser.open(url)
    except Exception:
        pass

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\nDemo stopped.")


if __name__ == "__main__":
    main()
