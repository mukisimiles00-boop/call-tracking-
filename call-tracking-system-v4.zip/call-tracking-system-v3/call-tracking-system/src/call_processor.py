"""
Turns raw AMI 'Cdr' events into normalised call records, and drives the
missed-call follow-up queue.
"""

import re
import logging
from datetime import datetime, timezone

log = logging.getLogger("call_processor")


def classify_direction(source, destination, extension_pattern):
    """
    Decide inbound / outbound / internal by checking which side of the call
    looks like a local extension, per extension_pattern in config.json.
    Adjust the pattern (and this function, if needed) to match how your
    S100 dial plan numbers extensions.
    """
    src_is_ext = bool(re.fullmatch(extension_pattern, source or ""))
    dst_is_ext = bool(re.fullmatch(extension_pattern, destination or ""))

    if src_is_ext and not dst_is_ext:
        return "outbound", source
    if dst_is_ext and not src_is_ext:
        return "inbound", destination
    if src_is_ext and dst_is_ext:
        return "internal", destination
    return "unknown", destination or source


def process_cdr_event(event, conn, config, notifier=None):
    if event.get("Event") != "Cdr":
        return None

    source = event.get("Source", "") or ""
    destination = event.get("Destination", "") or ""
    uniqueid = event.get("UniqueID") or f"{source}-{destination}-{event.get('StartTime')}"
    disposition = (event.get("Disposition") or "").strip()
    direction, extension = classify_direction(source, destination, config["extension_pattern"])

    try:
        duration = int(event.get("Duration") or 0)
    except ValueError:
        duration = 0
    try:
        billsec = int(event.get("BillableSeconds") or 0)
    except ValueError:
        billsec = 0

    cur = conn.execute(
        """INSERT OR IGNORE INTO calls
           (uniqueid, direction, caller, destination, extension,
            start_time, answer_time, end_time, duration, billsec, disposition)
           VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
        (
            uniqueid, direction, source, destination, extension,
            event.get("StartTime"), event.get("AnswerTime"), event.get("EndTime"),
            duration, billsec, disposition,
        ),
    )
    conn.commit()

    if cur.rowcount == 0:
        log.debug("Duplicate CDR event ignored (uniqueid=%s)", uniqueid)
        return None

    call_id = cur.lastrowid
    log.info("Logged %s call: %s -> %s [%s]", direction, source, destination, disposition)

    is_missed = direction == "inbound" and disposition != "ANSWERED"
    if is_missed:
        conn.execute(
            """INSERT INTO followups (call_id, caller, extension, missed_at, status)
               VALUES (?,?,?,?, 'open')""",
            (call_id, source, extension, event.get("EndTime") or datetime.now(timezone.utc).isoformat()),
        )
        conn.commit()
        log.info("Missed call queued for follow-up: %s -> ext %s", source, extension)
        if notifier:
            notifier.notify_missed_call(source, extension)

    # If this is an outbound call back to a number that has an open
    # follow-up, treat that follow-up as resolved.
    if direction == "outbound":
        resolved = conn.execute(
            """UPDATE followups SET status='resolved', resolved_at=CURRENT_TIMESTAMP
               WHERE caller = ? AND status='open'""",
            (destination,),
        )
        conn.commit()
        if resolved.rowcount:
            log.info("Resolved %s open follow-up(s) for %s via outbound call", resolved.rowcount, destination)

    return call_id
