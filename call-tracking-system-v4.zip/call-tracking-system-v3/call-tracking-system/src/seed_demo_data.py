"""
Fills the database with demo calls dated "now" so the dashboard has
something to show before you are connected to the real S100.

    python seed_demo_data.py          # add demo calls
    python seed_demo_data.py --clear  # remove only the demo calls again

Demo rows are tagged with a "demo-" id, so real calls are never touched.
"""

import json
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from db import get_connection

PROJECT_ROOT = Path(__file__).parent.parent


def load_db_path():
    with open(PROJECT_ROOT / "config.json") as f:
        config = json.load(f)
    db_path = Path(config["db_path"])
    if not db_path.is_absolute():
        db_path = (PROJECT_ROOT / db_path).resolve()
    return db_path


def ts(minutes_ago):
    t = datetime.now(timezone.utc) - timedelta(minutes=minutes_ago)
    return t.strftime("%Y-%m-%d %H:%M:%S")


# (id, direction, caller, destination, extension, minutes_ago, duration, disposition)
DEMO_CALLS = [
    ("demo-1", "inbound",  "0771234567", "1001", "1001", 120, 180, "ANSWERED"),
    ("demo-2", "inbound",  "0779876543", "1002", "1002", 45,   20, "NO ANSWER"),
    ("demo-3", "inbound",  "0771112222", "1001", "1001", 8,    15, "NO ANSWER"),
    ("demo-4", "outbound", "1001", "0779998888", "1001", 60,  120, "ANSWERED"),
    ("demo-5", "internal", "1001", "1002",       "1002", 30,   60, "ANSWERED"),
    ("demo-6", "inbound",  "0779990000", "1005", "1005", 5,    60, "ANSWERED"),
    ("demo-7", "inbound",  "0775550000", "1002", "1002", 90,   10, "NO ANSWER"),
    ("demo-8", "outbound", "1002", "0775550000", "1002", 75,   90, "ANSWERED"),
]


def clear(conn):
    ids = [r[0] for r in conn.execute("SELECT id FROM calls WHERE uniqueid LIKE 'demo-%'")]
    for call_id in ids:
        conn.execute("DELETE FROM followups WHERE call_id = ?", (call_id,))
    conn.execute("DELETE FROM calls WHERE uniqueid LIKE 'demo-%'")
    conn.commit()
    print(f"Removed {len(ids)} demo calls.")


def seed(conn):
    clear(conn)
    for uid, direction, caller, dest, ext, mins, dur, disp in DEMO_CALLS:
        start = ts(mins)
        end = ts(mins - dur / 60)
        answered = start if disp == "ANSWERED" else ""
        cur = conn.execute(
            """INSERT INTO calls (uniqueid, direction, caller, destination, extension,
                                  start_time, answer_time, end_time, duration, billsec, disposition)
               VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
            (uid, direction, caller, dest, ext, start, answered, end, dur,
             dur if disp == "ANSWERED" else 0, disp),
        )
        if direction == "inbound" and disp != "ANSWERED":
            # demo-7 was called back by demo-8, so that one is already resolved
            resolved = uid == "demo-7"
            conn.execute(
                """INSERT INTO followups (call_id, caller, extension, missed_at, status, resolved_at)
                   VALUES (?,?,?,?,?,?)""",
                (cur.lastrowid, caller, ext, end,
                 "resolved" if resolved else "open", ts(70) if resolved else None),
            )
    conn.commit()
    print(f"Added {len(DEMO_CALLS)} demo calls. Open the dashboard to see them.")


if __name__ == "__main__":
    conn = get_connection(str(load_db_path()))
    if "--clear" in sys.argv:
        clear(conn)
    else:
        seed(conn)
