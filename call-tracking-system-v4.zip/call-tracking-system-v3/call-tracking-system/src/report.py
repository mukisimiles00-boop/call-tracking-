"""
Weekly report: queries the call log, renders an HTML report, converts it to
PDF (via LibreOffice headless, which is free and commonly available on
Linux servers), then optionally sends it to a printer (via CUPS `lp`) and/or
emails it.
"""

import shutil
import smtplib
import subprocess
import logging
from email.message import EmailMessage
from datetime import datetime, timedelta, timezone
from pathlib import Path

log = logging.getLogger("report")


def _period_clause(column, start_s, end_s):
    """Build an optional 'BETWEEN' clause + params for a time column."""
    if start_s and end_s:
        return f" AND {column} BETWEEN ? AND ?", (start_s, end_s)
    return "", ()


def caller_report_data(conn, extension=None, start=None, end=None):
    """
    Build the per-caller report: for every external caller, how many of
    their calls were answered, how many were missed, how many of those
    missed calls were followed back (resolved), and how many are still
    waiting on a callback. Optionally filtered to one extension and/or a
    time window.

    Returns {"callers": [...], "totals": {...}} sorted by most missed first.
    """
    start_s = start.isoformat() if start else None
    end_s = end.isoformat() if end else None

    ext_clause = " AND extension = ?" if extension else ""
    ext_param = (extension,) if extension else ()

    call_period, call_pp = _period_clause("start_time", start_s, end_s)
    calls = conn.execute(
        f"""SELECT caller,
                  SUM(CASE WHEN disposition='ANSWERED' THEN 1 ELSE 0 END) answered,
                  SUM(CASE WHEN disposition!='ANSWERED' THEN 1 ELSE 0 END) missed,
                  MIN(start_time) first_call,
                  MAX(start_time) last_call
           FROM calls
           WHERE direction='inbound'{ext_clause}{call_period}
           GROUP BY caller""",
        (*ext_param, *call_pp),
    ).fetchall()

    fu_period, fu_pp = _period_clause("missed_at", start_s, end_s)
    followups = conn.execute(
        f"""SELECT caller,
                  SUM(CASE WHEN status='resolved' THEN 1 ELSE 0 END) followed_back,
                  SUM(CASE WHEN status='open' THEN 1 ELSE 0 END) still_open
           FROM followups
           WHERE 1=1{ext_clause}{fu_period}
           GROUP BY caller""",
        (*ext_param, *fu_pp),
    ).fetchall()

    fu_map = {r["caller"]: r for r in followups}

    rows = []
    for r in calls:
        fu = fu_map.get(r["caller"])
        followed_back = fu["followed_back"] if fu else 0
        still_open = fu["still_open"] if fu else 0
        rows.append({
            "caller": r["caller"] or "(unknown)",
            "answered": r["answered"] or 0,
            "missed": r["missed"] or 0,
            "followed_back": followed_back or 0,
            "still_open": still_open or 0,
            "total": (r["answered"] or 0) + (r["missed"] or 0),
            "first_call": r["first_call"],
            "last_call": r["last_call"],
        })

    # Callers who only ever appear as a missed follow-up (edge case) still show.
    for caller, fu in fu_map.items():
        if not any(row["caller"] == (caller or "(unknown)") for row in rows):
            rows.append({
                "caller": caller or "(unknown)",
                "answered": 0, "missed": 0,
                "followed_back": fu["followed_back"] or 0,
                "still_open": fu["still_open"] or 0,
                "total": 0, "first_call": None, "last_call": None,
            })

    rows.sort(key=lambda x: (-x["still_open"], -x["missed"], x["caller"]))

    totals = {
        "callers": len(rows),
        "answered": sum(x["answered"] for x in rows),
        "missed": sum(x["missed"] for x in rows),
        "followed_back": sum(x["followed_back"] for x in rows),
        "still_open": sum(x["still_open"] for x in rows),
    }
    return {"callers": rows, "totals": totals}


def generate_caller_report(conn, config, output_dir, start=None, end=None,
                           extension=None, staff_directory=None):
    """
    Render the per-caller report (every caller: missed, answered, followed
    back) to HTML, then convert to PDF via LibreOffice. Returns the file
    path (PDF, or HTML if LibreOffice isn't installed).
    """
    data = caller_report_data(conn, extension=extension, start=start, end=end)
    html = render_caller_html(data, start=start, end=end, extension=extension,
                              staff_directory=staff_directory or {})

    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    stamp = (end or datetime.now(timezone.utc)).strftime("%Y%m%d")
    html_path = output_dir / f"caller_report_{stamp}.html"
    html_path.write_text(html, encoding="utf-8")
    return _convert_to_pdf(html_path, output_dir)


def render_caller_html(data, start=None, end=None, extension=None, staff_directory=None):
    """Standalone, print-ready HTML for the per-caller report."""
    staff_directory = staff_directory or {}
    t = data["totals"]

    if start and end:
        period = f"{start:%Y-%m-%d} to {end:%Y-%m-%d}"
    else:
        period = "All time"
    scope = (f"{staff_directory.get(extension, 'Extension ' + extension)} (ext {extension})"
             if extension else "All staff")

    body_rows = "".join(
        f"<tr><td>{c['caller']}</td><td>{c['total']}</td>"
        f"<td class='ok'>{c['answered']}</td>"
        f"<td class='bad'>{c['missed']}</td>"
        f"<td class='good'>{c['followed_back']}</td>"
        f"<td class='{('bad' if c['still_open'] else '')}'>{c['still_open']}</td>"
        f"<td>{(c['last_call'] or '-')[:16].replace('T', ' ')}</td></tr>"
        for c in data["callers"]
    ) or "<tr><td colspan='7'>No calls logged for this period.</td></tr>"

    return f"""<!doctype html>
<html><head><meta charset="utf-8"><title>Caller Report</title><style>
  @page {{ size: 210mm 297mm; margin: 16mm; }}
  html, body {{ width: 178mm; }}
  body {{ font-family: Arial, Helvetica, sans-serif; color: #231F20; margin: 0; }}
  h1 {{ color: #C8102E; margin-bottom: 2px; }}
  .meta {{ color: #595959; margin: 0 0 4px; font-size: 13px; }}
  .summary {{ font-size: 14px; margin: 12px 0; }}
  .summary strong {{ color: #C8102E; }}
  table {{ border-collapse: collapse; width: 178mm; table-layout: fixed; margin-top: 10px; }}
  th, td {{ border: 1px solid #ccc; padding: 5px 8px; text-align: left; font-size: 12.5px; word-wrap: break-word; }}
  th {{ background: #C8102E; color: #fff; }}
  td.ok {{ color: #1e9e5a; font-weight: 700; }}
  td.good {{ color: #0b6ea8; font-weight: 700; }}
  td.bad {{ color: #C8102E; font-weight: 700; }}
  .print-btn {{
    display: inline-block; background: #C8102E; color: #fff; border: none;
    padding: 10px 20px; border-radius: 8px; font-size: 14px; font-weight: 700;
    cursor: pointer; margin: 10px 0;
  }}
  @media print {{ .print-btn, .no-print {{ display: none !important; }} }}
</style></head>
<body>
  <button class="print-btn" onclick="window.print()">Print this report</button>
  <h1>Caller Report</h1>
  <p class="meta">Period: {period} &nbsp;&middot;&nbsp; Scope: {scope} &nbsp;&middot;&nbsp; Generated {datetime.now():%Y-%m-%d %H:%M}</p>
  <div class="summary">
    <strong>{t['callers']}</strong> callers &nbsp;|&nbsp;
    <strong>{t['answered']}</strong> answered &nbsp;|&nbsp;
    <strong>{t['missed']}</strong> missed &nbsp;|&nbsp;
    <strong>{t['followed_back']}</strong> followed back &nbsp;|&nbsp;
    <strong>{t['still_open']}</strong> still open
  </div>
  <table>
    <tr><th style="width:30mm">Caller</th><th>Total calls</th><th>Answered</th>
        <th>Missed</th><th>Followed back</th><th>Still open</th><th style="width:34mm">Last call</th></tr>
    {body_rows}
  </table>
</body></html>"""


def weekly_report_data(conn, end=None):
    """Run the weekly queries and return (start, end, totals, followup_stats,
    per_ext, callers) so a report can be rendered without writing files."""
    end = end or datetime.now(timezone.utc)
    start = end - timedelta(days=7)
    start_s, end_s = start.isoformat(), end.isoformat()

    totals = conn.execute(
        "SELECT direction, COUNT(*) c FROM calls WHERE start_time BETWEEN ? AND ? GROUP BY direction",
        (start_s, end_s),
    ).fetchall()
    followup_stats = conn.execute(
        "SELECT status, COUNT(*) c FROM followups WHERE missed_at BETWEEN ? AND ? GROUP BY status",
        (start_s, end_s),
    ).fetchall()
    per_ext = conn.execute(
        """SELECT extension,
                  SUM(CASE WHEN direction='inbound' THEN 1 ELSE 0 END) inbound,
                  SUM(CASE WHEN direction='outbound' THEN 1 ELSE 0 END) outbound,
                  SUM(CASE WHEN direction='inbound' AND disposition!='ANSWERED' THEN 1 ELSE 0 END) missed
           FROM calls WHERE start_time BETWEEN ? AND ? GROUP BY extension ORDER BY extension""",
        (start_s, end_s),
    ).fetchall()
    callers = caller_report_data(conn, start=start, end=end)
    return start, end, totals, followup_stats, per_ext, callers


def weekly_report_html(conn, end=None):
    """Print-ready weekly report HTML (with a Print button) for the dashboard."""
    start, end, totals, followup_stats, per_ext, callers = weekly_report_data(conn, end=end)
    html = _render_html(start, end, totals, followup_stats, per_ext, callers)
    button = (
        '<button onclick="window.print()" style="display:inline-block;'
        'background:#C8102E;color:#fff;border:none;padding:10px 20px;'
        'border-radius:8px;font-size:14px;font-weight:700;cursor:pointer;'
        'margin:10px 0;" class="print-btn">Print this report</button>'
        '<style>@media print{.print-btn{display:none!important;}}</style>'
    )
    return html.replace("<body>", "<body>\n  " + button, 1)


def generate_weekly_report(conn, config, output_dir, end=None):
    start, end, totals, followup_stats, per_ext, callers = weekly_report_data(conn, end=end)

    html = _render_html(start, end, totals, followup_stats, per_ext, callers)

    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    html_path = output_dir / f"weekly_report_{end:%Y%m%d}.html"
    html_path.write_text(html, encoding="utf-8")

    pdf_path = _convert_to_pdf(html_path, output_dir)
    return pdf_path


def _render_html(start, end, totals, followup_stats, per_ext, callers=None):
    totals_map = {r["direction"]: r["c"] for r in totals}
    followup_map = {r["status"]: r["c"] for r in followup_stats}
    rows = "".join(
        f"<tr><td>{r['extension'] or '-'}</td><td>{r['inbound']}</td>"
        f"<td>{r['outbound']}</td><td>{r['missed']}</td></tr>"
        for r in per_ext
    ) or "<tr><td colspan='4'>No calls logged this period.</td></tr>"

    caller_list = (callers or {}).get("callers", [])
    caller_rows = "".join(
        f"<tr><td>{c['caller']}</td><td>{c['answered']}</td><td>{c['missed']}</td>"
        f"<td>{c['followed_back']}</td><td>{c['still_open']}</td></tr>"
        for c in caller_list
    ) or "<tr><td colspan='5'>No callers this period.</td></tr>"

    return f"""<!doctype html>
<html><head><meta charset="utf-8"><style>
  @page {{ size: 210mm 297mm; margin: 20mm; }}
  html, body {{ width: 170mm; }}
  body {{ font-family: Arial, Helvetica, sans-serif; color: #231F20; margin: 0; }}
  h1 {{ color: #C8102E; margin-bottom: 4px; }}
  .period {{ color: #595959; margin-top: 0; }}
  table {{ border-collapse: collapse; width: 170mm; table-layout: fixed; margin-top: 12px; }}
  th, td {{ border: 1px solid #ccc; padding: 6px 10px; text-align: left; font-size: 14px; word-wrap: break-word; }}
  th {{ background: #C8102E; color: #fff; width: 42.5mm; }}
  .summary {{ font-size: 15px; margin: 14px 0; }}
</style></head>
<body>
  <h1>Weekly Call Report</h1>
  <p class="period">{start:%Y-%m-%d} to {end:%Y-%m-%d}</p>

  <div class="summary">
    <strong>Inbound:</strong> {totals_map.get('inbound', 0)} &nbsp;|&nbsp;
    <strong>Outbound:</strong> {totals_map.get('outbound', 0)} &nbsp;|&nbsp;
    <strong>Internal:</strong> {totals_map.get('internal', 0)}
  </div>
  <div class="summary">
    <strong>Missed-call follow-ups resolved:</strong> {followup_map.get('resolved', 0)} &nbsp;|&nbsp;
    <strong>Still open:</strong> {followup_map.get('open', 0)}
  </div>

  <h2>Per-Extension Breakdown</h2>
  <table>
    <tr><th>Extension</th><th>Inbound</th><th>Outbound</th><th>Missed</th></tr>
    {rows}
  </table>

  <h2>Per-Caller Breakdown</h2>
  <table>
    <tr><th>Caller</th><th>Answered</th><th>Missed</th><th>Followed back</th><th>Still open</th></tr>
    {caller_rows}
  </table>
</body></html>"""


def _convert_to_pdf(html_path, output_dir):
    soffice = shutil.which("soffice") or shutil.which("libreoffice")
    if not soffice:
        log.warning("LibreOffice not found on this system - report left as HTML only (%s)", html_path)
        return html_path
    subprocess.run(
        [soffice, "--headless", "--convert-to", "pdf", "--outdir", str(output_dir), str(html_path)],
        check=True, capture_output=True,
    )
    return html_path.with_suffix(".pdf")


def print_report(pdf_path, printer_name):
    lp = shutil.which("lp")
    if not lp:
        log.warning("`lp` (CUPS) not found - install/enable CUPS to auto-print, or print %s manually", pdf_path)
        return False
    subprocess.run([lp, "-d", printer_name, str(pdf_path)], check=True)
    log.info("Sent %s to printer '%s'", pdf_path, printer_name)
    return True


def email_report(pdf_path, config):
    email_cfg = config.get("email", {})
    recipients = config.get("report_email_to") or []
    if not email_cfg.get("enabled") or not recipients:
        return False

    msg = EmailMessage()
    msg["Subject"] = f"Weekly Call Report - {pdf_path.stem}"
    msg["From"] = email_cfg["from_address"]
    msg["To"] = ", ".join(recipients)
    msg.set_content("Attached: this week's call report.")
    msg.add_attachment(
        Path(pdf_path).read_bytes(), maintype="application", subtype="pdf", filename=pdf_path.name
    )

    with smtplib.SMTP(email_cfg["smtp_host"], email_cfg.get("smtp_port", 587)) as server:
        if email_cfg.get("use_tls", True):
            server.starttls()
        if email_cfg.get("smtp_user"):
            server.login(email_cfg["smtp_user"], email_cfg["smtp_password"])
        server.send_message(msg)
    log.info("Report emailed to %s", recipients)
    return True
