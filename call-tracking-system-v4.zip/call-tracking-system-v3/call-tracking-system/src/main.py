"""
Entry point for the always-on AMI listener. Run this as a service (see
systemd/call-tracker.service) so it reconnects automatically if the S100
or the network drops.
"""

import json
import logging
import time
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from ami_client import AMIClient, AMIError
from db import get_connection
from call_processor import process_cdr_event
from notifier import Notifier

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
log = logging.getLogger("main")


def load_config():
    config_path = Path(__file__).parent.parent / "config.json"
    with open(config_path) as f:
        return json.load(f)


def main():
    config = load_config()
    conn = get_connection(config["db_path"])
    notifier = Notifier(config)

    def handle_event(event):
        try:
            process_cdr_event(event, conn, config, notifier)
        except Exception:
            log.exception("Error processing event: %s", event)

    backoff = 5
    while True:
        client = AMIClient(
            config["ami_host"], config["ami_port"],
            config["ami_username"], config["ami_secret"],
            handle_event,
        )
        try:
            client.connect()
            backoff = 5  # reset after a successful connection
            client.run_forever()
        except (AMIError, OSError) as e:
            log.error("AMI connection lost (%s). Reconnecting in %ss", e, backoff)
        finally:
            client.close()
        time.sleep(backoff)
        backoff = min(backoff * 2, 60)


if __name__ == "__main__":
    main()
