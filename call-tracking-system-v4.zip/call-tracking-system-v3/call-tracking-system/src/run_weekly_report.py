"""
Generates, prints, and emails the weekly report. Intended to be triggered
by cron (see README.md for the crontab entry) - e.g. every Monday at 07:00.
"""

import json
import logging
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from db import get_connection
from report import generate_weekly_report, print_report, email_report

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
log = logging.getLogger("weekly_report")


def load_config():
    config_path = Path(__file__).parent.parent / "config.json"
    with open(config_path) as f:
        return json.load(f)


def main():
    config = load_config()
    conn = get_connection(config["db_path"])

    pdf_path = generate_weekly_report(conn, config, config["report_output_dir"])
    log.info("Report generated: %s", pdf_path)

    if config.get("printer_name"):
        print_report(pdf_path, config["printer_name"])

    if config.get("email", {}).get("enabled"):
        email_report(pdf_path, config)


if __name__ == "__main__":
    main()
