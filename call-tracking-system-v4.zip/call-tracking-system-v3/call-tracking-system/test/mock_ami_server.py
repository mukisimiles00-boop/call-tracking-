"""
A tiny fake AMI server that mimics an Asterisk/Yeastar S100 well enough to
test the listener against, without touching your real phone system.

Usage:
    python3 mock_ami_server.py            # runs once, sends sample events, exits
"""

import socket
import time

SAMPLE_EVENTS = [
    # Answered inbound call
    {
        "Event": "Cdr", "Source": "0771234567", "Destination": "1001",
        "Channel": "SIP/trunk-00000001",
        "StartTime": "2026-09-15 09:00:00", "AnswerTime": "2026-09-15 09:00:05",
        "EndTime": "2026-09-15 09:03:00", "Duration": "180", "BillableSeconds": "175",
        "Disposition": "ANSWERED", "UniqueID": "1.001",
    },
    # Missed inbound call -> should create a follow-up
    {
        "Event": "Cdr", "Source": "0779876543", "Destination": "1002",
        "Channel": "SIP/trunk-00000002",
        "StartTime": "2026-09-15 10:00:00", "AnswerTime": "",
        "EndTime": "2026-09-15 10:00:20", "Duration": "20", "BillableSeconds": "0",
        "Disposition": "NO ANSWER", "UniqueID": "1.002",
    },
    # Outbound callback to the same number that was missed -> should resolve it
    {
        "Event": "Cdr", "Source": "1002", "Destination": "0779876543",
        "Channel": "SIP/1002-00000003",
        "StartTime": "2026-09-15 10:05:00", "AnswerTime": "2026-09-15 10:05:03",
        "EndTime": "2026-09-15 10:06:00", "Duration": "60", "BillableSeconds": "57",
        "Disposition": "ANSWERED", "UniqueID": "1.003",
    },
]


def _serve_one(server):
    conn, addr = server.accept()
    print(f"[mock-ami] connection from {addr}")
    try:
        conn.sendall(b"Asterisk Call Manager/2.10.3\r\n")

        # Read the Login action (terminated by a blank line)
        data = b""
        while b"\r\n\r\n" not in data:
            chunk = conn.recv(4096)
            if not chunk:
                print("[mock-ami] client left before logging in")
                return
            data += chunk
        print("[mock-ami] received login action")

        conn.sendall(b"Response: Success\r\nMessage: Authentication accepted\r\n\r\n")

        for ev in SAMPLE_EVENTS:
            block = "".join(f"{k}: {v}\r\n" for k, v in ev.items()) + "\r\n"
            conn.sendall(block.encode())
            print(f"[mock-ami] sent event uniqueid={ev['UniqueID']}")
            time.sleep(0.2)
        time.sleep(0.5)
    except (ConnectionError, OSError) as e:
        print(f"[mock-ami] client disconnected early ({e}) - that's fine")
    finally:
        conn.close()
        print("[mock-ami] connection closed")


def run(host="127.0.0.1", port=15038, forever=False):
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind((host, port))
    server.listen(5)
    print(f"[mock-ami] listening on {host}:{port}")
    try:
        while True:
            _serve_one(server)
            if not forever:
                break
    except KeyboardInterrupt:
        print("\n[mock-ami] stopped")
    finally:
        server.close()


if __name__ == "__main__":
    run(forever=True)