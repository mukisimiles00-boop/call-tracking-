"""
End-to-end test: spins up the mock AMI server, runs the real AMIClient +
call_processor against it, then checks the database and weekly report
came out correctly. No real PBX involved - this only proves the code works.
"""

import sys
import threading
import tempfile
import shutil
from pathlib import Path
from datetime import datetime, timezone

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))
sys.path.insert(0, str(Path(__file__).parent))

from ami_client import AMIClient, AMIError
from db import get_connection
from call_processor import process_cdr_event
from report import generate_weekly_report
import mock_ami_server

HOST, PORT = "127.0.0.1", 15038


def main():
    tmp_dir = Path(tempfile.mkdtemp(prefix="call_tracker_test_"))
    db_path = tmp_dir / "calls.db"
    reports_dir = tmp_dir / "reports"

    server_thread = threading.Thread(target=mock_ami_server.run, args=(HOST, PORT), daemon=True)
    server_thread.start()

    conn = get_connection(str(db_path))
    config = {"extension_pattern": r"^[1-9][0-9]{2,3}$"}

    events_received = []

    def handle_event(event):
        events_received.append(event)
        process_cdr_event(event, conn, config, notifier=None)

    client = AMIClient(HOST, PORT, "test-user", "test-secret", handle_event)
    client.connect()
    try:
        client.run_forever()
    except AMIError:
        pass  # mock server closes the connection when it's done - expected
    finally:
        client.close()

    server_thread.join(timeout=2)

    # --- Assertions ---
    calls = conn.execute("SELECT * FROM calls ORDER BY id").fetchall()
    followups = conn.execute("SELECT * FROM followups ORDER BY id").fetchall()

    assert len(calls) == 3, f"expected 3 calls logged, got {len(calls)}"
    assert calls[0]["direction"] == "inbound" and calls[0]["disposition"] == "ANSWERED"
    assert calls[1]["direction"] == "inbound" and calls[1]["disposition"] == "NO ANSWER"
    assert calls[2]["direction"] == "outbound"

    assert len(followups) == 1, f"expected 1 follow-up created, got {len(followups)}"
    assert followups[0]["status"] == "resolved", "follow-up should auto-resolve after the callback"

    print("[test] calls table:      3 rows, directions/dispositions correct  -> PASS")
    print("[test] followups table:  created on miss, auto-resolved on callback -> PASS")

    # --- Report generation ---
    pdf_path = generate_weekly_report(
        conn, config, str(reports_dir),
        end=datetime(2026, 9, 16, tzinfo=timezone.utc),
    )
    assert Path(pdf_path).exists(), f"report file not found at {pdf_path}"
    print(f"[test] weekly report generated: {pdf_path.name} -> PASS")

    shutil.rmtree(tmp_dir, ignore_errors=True)
    print("\nAll checks passed.")


if __name__ == "__main__":
    main()
