# Masca Call Tracking System

Connects to the Yeastar S100 PBX over AMI, logs every inbound/outbound/missed
call, tracks missed calls through to follow-up, and produces a printed
weekly report.

See the chat message this was delivered with for the full step-by-step
guide to connecting it to your S100. Quick reference:

## Install

```bash
sudo mkdir -p /opt/call-tracking-system
sudo cp -r . /opt/call-tracking-system
cd /opt/call-tracking-system
cp config.example.json config.json
# edit config.json: ami_host, ami_username, ami_secret, extension_pattern, etc.
```

Requires: Python 3.8+ (stdlib only, no pip installs needed), LibreOffice
(`soffice`) for PDF conversion, and CUPS (`lp` command) if you want
automatic printing.

## Test without a real PBX

```bash
cd test
python3 mock_ami_server.py &
cd ../src && python3 -c "
import json
# point a temp config at the mock server on 127.0.0.1:15038 and run main.py briefly
"
python3 test_pipeline.py   # from test/, runs an automated end-to-end check
```

## Run the listener (production)

```bash
sudo cp systemd/call-tracker.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now call-tracker
sudo journalctl -u call-tracker -f      # watch logs
```

## Run the live dashboard

A fun, live "Call Command Center" dashboard is included for whoever is
monitoring calls day to day - stat cards, an urgency-colour-coded
follow-up queue, a live call feed, and a leaderboard of who resolves
follow-ups fastest. It reads the same database the listener writes to,
polling every 5 seconds, no page reload needed.

```bash
cd src && python3 dashboard_server.py
```

Then open `http://<server-IP>:8088` in a browser - from the server itself,
or from any other machine on the same network.

**Admin login & per-person views:** the dashboard sits behind a single
login (set `admin_username` / `admin_password` in config.json - leave
either blank to disable the login entirely). Once logged in, a dropdown
at the top switches the whole dashboard between **"All Staff"** (everyone
with a phone, the default view) and any one named person - selecting a
person filters every panel (stats, follow-ups, live feed) down to just
their extension. Name the extensions that matter to you under
`staff_directory` in config.json; any extension seen on a call that
isn't named there still shows up automatically as "Extension 1005" so
nothing gets hidden just because it hasn't been labelled yet.

To keep it running permanently:

```bash
sudo cp systemd/call-dashboard.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now call-dashboard
```

## Admin reports (print from the dashboard)

The admin can print two reports straight from the Call Command Center -
two buttons sit at the top-right of the dashboard, next to the staff
selector:

- **Caller Report** - a report for *every caller*, showing for each one
  how many of their calls were **answered**, how many were **missed**,
  how many of those missed calls were **followed back** (resolved), and
  how many are still open. Opens as a clean, print-ready page with a
  **Print this report** button - click it and your browser's print
  dialog sends it to any printer (or "Save as PDF"). If a single person
  is selected in the staff dropdown, the Caller Report button is
  automatically scoped to that extension only.
- **Weekly Report** - the last 7 days: inbound/outbound/internal totals,
  follow-ups resolved vs. still open, a per-extension breakdown, and a
  per-caller breakdown. Same one-click Print button.

Both pages are plain HTML printed by the browser, so **no extra software
is needed** on the admin's machine. They read live from the same
database, so what you print always matches what's on screen.

You can also build the caller report from the command line / cron
(generates a PDF via LibreOffice and sends it to the configured printer
via CUPS, exactly like the weekly report):

```bash
cd src
python3 run_caller_report.py            # all-time, send to the printer
python3 run_caller_report.py --days 7    # just the last 7 days
python3 run_caller_report.py --no-print  # build the file only, don't print
```

## Schedule the weekly report

```bash
crontab -e
# add:
0 7 * * MON cd /opt/call-tracking-system/src && /usr/bin/python3 run_weekly_report.py >> /opt/call-tracking-system/logs/report.log 2>&1
```

## Files

- `src/ami_client.py` — raw AMI TCP client (no external dependencies)
- `src/db.py` — SQLite schema + connection helper
- `src/call_processor.py` — classifies calls, detects missed calls, manages follow-ups
- `src/notifier.py` — email alert on missed call (optional, off by default)
- `src/report.py` — builds the weekly + per-caller HTML/PDF reports, printing, emailing
- `src/main.py` — listener daemon entry point
- `src/dashboard_server.py` — fun live web dashboard for call monitoring, with Caller/Weekly report print buttons
- `src/run_weekly_report.py` — cron entry point for the weekly report
- `src/run_caller_report.py` — manual/cron entry point for the per-caller report
- `test/mock_ami_server.py` — fake AMI server for testing
- `test/test_pipeline.py` — automated end-to-end test
- `systemd/call-tracker.service` — service unit for the always-on listener
- `systemd/call-dashboard.service` — service unit for the dashboard
